<?php
declare(strict_types=1);

return [
    'schema' => 'hoosier_online.logo_assets.v3',
    'version' => 'HO-LOGO-ASSETS-003',
    'source' => 'approved uploaded logo direction',
    'assets' => [
        'logo_primary_svg' => '/assets/brand/logo_primary.svg',
        'logo_primary_png' => '/assets/brand/logo_primary.png',
        'logo_mark_svg' => '/assets/brand/logo_mark.svg',
        'logo_mark_png' => '/assets/brand/logo_mark.png',
        'favicon_ico' => '/assets/brand/favicon.ico',
        'social_preview_png' => '/assets/brand/social_preview.png',
    ],
    'logo_direction' => [
        'Keep colors and words the same as the approved logo.',
        'Use red segmented basketball/H emblem instead of Indiana/star mark.',
        'HOOSIER remains strong, black, condensed, hardworking, and readable.',
        'ONLINE remains smaller, letter-spaced, and green.',
        'Gold divider bars remain around ONLINE.',
    ],
];
