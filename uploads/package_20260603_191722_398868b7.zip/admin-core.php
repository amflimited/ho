<?php
declare(strict_types=1);

const HO_ADMIN_CORE_VERSION = 'HO-ADMIN-CORE-022';

function ho_admin_config(): array {
    return [
        'schema' => 'hoosier_online.admin_core.v1',
        'version' => HO_ADMIN_CORE_VERSION,
        'future_auth' => [
            'enabled_now' => false,
            'planned' => true,
            'login_page_reserved' => '/login.php',
        ],
        'brand' => [
            'logo_primary' => '/assets/brand/logo_primary.png',
            'favicon' => '/favicon.ico',
        ],
        'menu' => [
            ['key' => 'dashboard', 'label' => 'Dashboard', 'url' => '/admin.php'],
            ['key' => 'upload', 'label' => 'Upload', 'url' => '/upload.php'],
            ['key' => 'sitemap', 'label' => 'Sitemap / Backup', 'url' => '/sitemap.php'],
            ['key' => 'product', 'label' => 'Product', 'url' => '/product.php'],
            ['key' => 'sales', 'label' => 'Sales', 'url' => '/salesphilosophy.php'],
        ],
    ];
}

function ho_h(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function ho_admin_is_active(string $active, string $key): string {
    return $active === $key ? ' class="is-active"' : '';
}

function ho_admin_render_start(string $active, string $title, string $kicker, string $headline, string $lead = ''): void {
    $config = ho_admin_config();
    $machine = [
        'schema' => 'hoosier_online.admin_page.v1',
        'core_version' => HO_ADMIN_CORE_VERSION,
        'active' => $active,
        'menu_source' => 'admin-core.php',
        'future_auth_planned' => true,
    ];
    ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= ho_h($title) ?></title>
  <link rel="icon" href="<?= ho_h($config['brand']['favicon']) ?>">
  <link rel="stylesheet" href="/assets/css/admin.css?v=022-admin-links">
  <script type="application/json" id="ho-admin-machine"><?= ho_h(json_encode($machine, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></script>
</head>
<body>
  <main class="admin-shell">
    <div class="admin-topbar">
      <a class="admin-logo" href="/index.php" aria-label="Hoosier Online public site">
        <img src="<?= ho_h($config['brand']['logo_primary']) ?>" alt="Hoosier Online">
      </a>

      <nav class="admin-nav" aria-label="Admin menu">
        <?php foreach ($config['menu'] as $item): ?>
          <a<?= ho_admin_is_active($active, $item['key']) ?> href="<?= ho_h($item['url']) ?>"><?= ho_h($item['label']) ?></a>
        <?php endforeach; ?>
      </nav>
    </div>

    <section class="admin-page">
      <header class="admin-page-head">
        <p class="admin-kicker"><?= ho_h($kicker) ?></p>
        <h1 class="admin-title"><?= $headline ?></h1>
        <?php if ($lead !== ''): ?>
          <p class="admin-lead"><?= ho_h($lead) ?></p>
        <?php endif; ?>
      </header>

      <section class="admin-body">
    <?php
}

function ho_admin_render_end(): void {
    ?>
      </section>
    </section>
  </main>
</body>
</html>
    <?php
}
