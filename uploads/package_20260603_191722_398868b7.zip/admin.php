<?php
declare(strict_types=1);

require __DIR__ . '/admin-core.php';

ho_admin_render_start(
    'dashboard',
    'Hoosier Online Admin',
    'Admin',
    'Admin <em>Hub</em>',
    ''
);
?>
<div class="admin-grid">
  <article class="admin-card admin-card-action">
    <h2>Upload</h2>
    <a class="admin-btn admin-btn-secondary" href="/upload.php">Open Upload</a>
  </article>

  <article class="admin-card admin-card-action">
    <h2>Sitemap / Backup</h2>
    <a class="admin-btn admin-btn-primary" href="/sitemap.php">Open Sitemap</a>
  </article>

  <article class="admin-card admin-card-action">
    <h2>Product</h2>
    <a class="admin-btn admin-btn-secondary" href="/product.php">Open Product</a>
  </article>

  <article class="admin-card admin-card-action">
    <h2>Sales</h2>
    <a class="admin-btn admin-btn-secondary" href="/salesphilosophy.php">Open Sales</a>
  </article>
</div>
<?php
ho_admin_render_end();
