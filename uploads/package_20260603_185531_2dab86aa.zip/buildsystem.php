<?php
declare(strict_types=1);

$buildsystem = json_decode(<<<'JSON'
{
  "schema": "hoosier_online.build_system.v1",
  "version": "HO-BUILD-SYSTEM-023",
  "purpose": "Defines how Hoosier Online fulfills a Business Front Door after a customer chooses and pays.",
  "fulfillment_thesis": "The Front Door build should be modular, fast, templated, and personalized from customer inputs and preview choices. The customer should not have to invent a website plan from scratch.",
  "core_flow": [
    "Receive order or approved Front Door choices.",
    "Confirm package: Standard or Managed.",
    "Collect required customer inputs.",
    "Choose template family and modules.",
    "Assemble first build.",
    "Connect contact/request/payment paths.",
    "Run quality checks.",
    "Send preview for approval.",
    "Apply reasonable launch fixes.",
    "Launch and record service/renewal terms."
  ],
  "build_stages": [
    {
      "stage": "Intake",
      "goal": "Collect enough information to build without chasing the customer repeatedly.",
      "outputs": [
        "customer intake record",
        "asset links",
        "business info",
        "selected package",
        "selected design direction",
        "selected features"
      ]
    },
    {
      "stage": "Structure",
      "goal": "Decide which Front Door modules are needed.",
      "outputs": [
        "module list",
        "page structure",
        "form structure",
        "payment/contact requirements"
      ]
    },
    {
      "stage": "Design Direction",
      "goal": "Apply a prebuilt visual direction without starting from scratch.",
      "outputs": [
        "template family",
        "color treatment",
        "section style",
        "photo treatment"
      ]
    },
    {
      "stage": "Content Assembly",
      "goal": "Turn business info into clean public-facing copy and sections.",
      "outputs": [
        "hero copy",
        "service/product cards",
        "about/summary",
        "proof/gallery captions",
        "CTA text"
      ]
    },
    {
      "stage": "Build",
      "goal": "Create the hosted Front Door page/app.",
      "outputs": [
        "public page/app",
        "forms",
        "links/buttons",
        "gallery/display modules",
        "mobile layout"
      ]
    },
    {
      "stage": "Connection",
      "goal": "Make the customer action paths work.",
      "outputs": [
        "request form notifications",
        "click-to-call",
        "email/message links",
        "booking link",
        "payment/deposit link if needed"
      ]
    },
    {
      "stage": "QA",
      "goal": "Catch obvious problems before the customer sees it.",
      "outputs": [
        "desktop check",
        "mobile check",
        "form test",
        "link test",
        "spelling/basic copy check",
        "contact/payment path check"
      ]
    },
    {
      "stage": "Approval",
      "goal": "Let the customer confirm the build without opening unlimited revision loops.",
      "outputs": [
        "preview link",
        "customer approval",
        "reasonable fixes list"
      ]
    },
    {
      "stage": "Launch",
      "goal": "Move the Front Door into its public/customer-ready state.",
      "outputs": [
        "live URL",
        "admin/service record",
        "renewal date",
        "support level"
      ]
    },
    {
      "stage": "Service",
      "goal": "Maintain the Front Door according to package terms.",
      "outputs": [
        "update log",
        "renewal tracking",
        "support notes",
        "future upgrade opportunities"
      ]
    }
  ],
  "template_families": [
    {
      "name": "Clean Local Pro",
      "best_for": [
        "cleaning",
        "home services",
        "professional local services",
        "general service businesses"
      ],
      "feel": "clean, trustworthy, simple, approachable",
      "default_modules": [
        "Hero",
        "Services / Offers",
        "Trust / Proof",
        "Contact / Request",
        "Service Area",
        "Footer"
      ]
    },
    {
      "name": "Bold Work Truck",
      "best_for": [
        "lawn care",
        "construction",
        "handyman",
        "pressure washing",
        "landscaping",
        "trades"
      ],
      "feel": "strong, direct, practical, work-ready",
      "default_modules": [
        "Hero",
        "Services / Offers",
        "Gallery / Before After",
        "Request Estimate",
        "Service Area",
        "Payment / Deposit"
      ]
    },
    {
      "name": "Warm Neighborhood",
      "best_for": [
        "family businesses",
        "local shops",
        "home-based services",
        "community businesses"
      ],
      "feel": "warm, local, personal, friendly",
      "default_modules": [
        "Hero",
        "Business Summary",
        "Services / Offers",
        "Proof / Photos",
        "Contact",
        "Social / Google"
      ]
    },
    {
      "name": "Sharp Modern",
      "best_for": [
        "detailing",
        "photography",
        "premium services",
        "specialty services"
      ],
      "feel": "sleek, visual, polished, premium",
      "default_modules": [
        "Hero",
        "Portfolio / Gallery",
        "Packages",
        "Booking / Request",
        "Proof",
        "Payment / Deposit"
      ]
    },
    {
      "name": "Simple Menu Board",
      "best_for": [
        "food vendors",
        "shops",
        "products",
        "menus",
        "service lists"
      ],
      "feel": "scannable, clear, item-forward, easy to update",
      "default_modules": [
        "Hero",
        "Menu / Catalog",
        "Featured Items",
        "Order / Request",
        "Hours / Location",
        "Payment"
      ]
    }
  ],
  "feature_modules": [
    {
      "name": "Contact/request form",
      "purpose": "Collect usable customer inquiries."
    },
    {
      "name": "Services/products section",
      "purpose": "Show what the business offers."
    },
    {
      "name": "Gallery/work examples",
      "purpose": "Show proof and examples."
    },
    {
      "name": "Booking/request path",
      "purpose": "Let customers request a time, job, appointment, estimate, or consultation."
    },
    {
      "name": "Payment/deposit link",
      "purpose": "Make payment or deposit simple."
    },
    {
      "name": "Google/Facebook links",
      "purpose": "Connect existing public profiles."
    },
    {
      "name": "Reviews/testimonials",
      "purpose": "Build credibility."
    },
    {
      "name": "Service area",
      "purpose": "Clarify where work is available."
    },
    {
      "name": "Photo upload on request form",
      "purpose": "Help customers provide job details."
    },
    {
      "name": "Before/after section",
      "purpose": "Show transformation or quality."
    }
  ],
  "from_preview_to_build_mapping": {
    "package_standard": "Use standard module set, launch-quality copy, basic cleanup, and light maintenance rules.",
    "package_managed": "Use expanded module set, more hands-on content loading, more cleanup, more form/workflow refinement, and managed support rules.",
    "design_direction": "Maps to one template family.",
    "selected_features": "Maps to feature modules.",
    "business_goal": "Prioritizes section order and calls to action.",
    "weaknesses": "Determine which Me categories need the strongest emphasis.",
    "strengths": "Determine which proof and trust signals should be highlighted."
  },
  "qa_checklist": [
    "Logo/business name appears correctly.",
    "Phone number works on mobile.",
    "Email/contact link works.",
    "Request form submits correctly.",
    "Form notification goes to the correct recipient.",
    "Required fields make sense.",
    "Primary call to action is visible above the fold.",
    "Services/products/work display is understandable.",
    "Photos are not broken or stretched.",
    "Mobile layout does not overflow.",
    "Google/Facebook/social links work.",
    "Payment/deposit link works if included.",
    "Spelling and obvious copy errors are checked.",
    "No placeholder content remains.",
    "Footer business info is accurate."
  ],
  "launch_checklist": [
    "Customer has reviewed the preview.",
    "Reasonable launch fixes are complete.",
    "Final URL is confirmed.",
    "Contact/request path is tested.",
    "Payment/deposit path is tested if included.",
    "Renewal/service terms are recorded.",
    "Customer receives live link.",
    "Customer receives basic use/support explanation.",
    "Internal update log is created."
  ],
  "support_rules": {
    "standard": [
      "Light updates and maintenance during included year.",
      "Reasonable small changes only.",
      "Larger additions quoted separately.",
      "Renewal after year one: $250/year or $25/month."
    ],
    "managed": [
      "More active support during included 3 months.",
      "More frequent content and workflow adjustments.",
      "Priority fixes during active managed period.",
      "Renewal after included period: $250/quarter or $750/year."
    ]
  },
  "fulfillment_boundaries": [
    "Do not accept unlimited revision cycles.",
    "Do not let missing customer content become Hoosier Online failure.",
    "Do not promise same-day completion unless all required information is ready and scope is simple.",
    "Do not include paid ads, major integrations, or custom software without separate quote.",
    "Do not become responsible for answering leads or running the customer's business."
  ]
}
JSON, true);

if (isset($_GET['format']) && $_GET['format'] === 'json') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($buildsystem, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') !== realpath(__FILE__)) {
    return $buildsystem;
}

function hp_h(mixed $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function hp_list(array $items): string {
    $html = '<ul class="doc-list">';
    foreach ($items as $item) {
        if (is_array($item)) {
            $item = json_encode($item, JSON_UNESCAPED_SLASHES);
        }
        $html .= '<li>' . hp_h($item) . '</li>';
    }
    $html .= '</ul>';
    return $html;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hoosier Online Build System</title>
  <link rel="icon" href="/favicon.ico">
  <link rel="stylesheet" href="/assets/css/site.css?v=023-docs">
  <link rel="stylesheet" href="/assets/css/admin.css?v=023-docs">
  <script type="application/json" id="ho-doc-machine"><?= hp_h(json_encode($buildsystem, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></script>
  <style>
    body { background: var(--ho-bg, #F8F1E3); }
    .doc-shell { width: min(1120px, calc(100% - 28px)); margin: 0 auto; padding: 26px 0 52px; }
    .doc-topbar { display: flex; justify-content: space-between; align-items: center; gap: 16px; margin-bottom: 18px; }
    .doc-logo img { width: clamp(220px, 24vw, 330px); height: auto; display: block; filter: drop-shadow(0 8px 14px rgba(84,58,31,.06)); }
    .doc-actions { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 8px; }
    .doc-panel { background: linear-gradient(180deg, rgba(255,253,247,.84), rgba(255,248,234,.72)); border: 1px solid var(--ho-border, rgba(139,104,68,.22)); border-radius: 34px; box-shadow: 0 24px 80px rgba(84,58,31,.10), inset 0 1px 0 rgba(255,255,255,.76); overflow: hidden; }
    .doc-hero { padding: clamp(28px, 5vw, 48px); border-bottom: 1px solid rgba(139,104,68,.18); background: radial-gradient(circle at 88% 0%, rgba(233,169,40,.14), transparent 18rem), linear-gradient(135deg, rgba(177,18,23,.045), transparent 40%), rgba(255,248,234,.62); }
    .doc-kicker { margin: 0 0 10px; color: var(--ho-primary, #B11217); text-transform: uppercase; letter-spacing: .18em; font-size: 12px; font-weight: 880; }
    .doc-title { margin: 0; font-family: var(--ho-font-display, "Arial Narrow", sans-serif); font-size: clamp(54px, 8vw, 104px); line-height: .86; letter-spacing: .03em; text-transform: uppercase; }
    .doc-title em { color: var(--ho-primary, #B11217); font-style: normal; }
    .doc-lead { max-width: 78ch; margin: 16px 0 0; color: var(--ho-muted, #6E665C); font-size: 18px; }
    .doc-body { padding: clamp(20px, 3vw, 30px); display: grid; gap: 22px; }
    .doc-section { border: 1px solid var(--ho-border, rgba(139,104,68,.22)); border-radius: 28px; padding: clamp(20px, 3vw, 28px); background: linear-gradient(180deg, rgba(255,255,255,.70), rgba(255,253,247,.56)); box-shadow: 0 14px 42px rgba(84,58,31,.06); }
    .doc-section h2 { margin: 0 0 14px; font-family: var(--ho-font-display, "Arial Narrow", sans-serif); font-size: clamp(38px, 5vw, 58px); line-height: .92; letter-spacing: .04em; text-transform: uppercase; }
    .doc-section h3 { margin: 0 0 8px; font-family: var(--ho-font-display, "Arial Narrow", sans-serif); font-size: 30px; line-height: .96; letter-spacing: .035em; text-transform: uppercase; color: var(--ho-secondary, #2F6338); }
    .doc-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
    .doc-grid-three { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }
    .doc-card { border: 1px solid var(--ho-border, rgba(139,104,68,.22)); border-radius: 24px; padding: 20px; background: rgba(255,255,255,.62); }
    .doc-price { font-family: var(--ho-font-display, "Arial Narrow", sans-serif); font-size: clamp(48px, 6vw, 72px); line-height: .86; color: var(--ho-primary, #B11217); margin: 4px 0 10px; }
    .doc-sub { color: var(--ho-muted, #6E665C); margin: 0 0 14px; }
    .doc-list { margin: 10px 0 0; padding-left: 20px; }
    .doc-list li + li { margin-top: 5px; }
    .doc-quote { margin: 0; padding: 20px; border-left: 6px solid var(--ho-primary, #B11217); border-radius: 18px; background: rgba(255,255,255,.58); font-size: 19px; }
    .machine-note { color: var(--ho-muted, #6E665C); font-size: 13px; }
    @media (max-width: 820px) { .doc-topbar, .doc-grid, .doc-grid-three { grid-template-columns: 1fr; display: grid; } .doc-actions { justify-content: flex-start; } .doc-logo img { width: min(335px, 86vw); } .doc-panel { border-radius: 28px; } }
  </style>
</head>
<body>
  <main class="doc-shell">
    <div class="doc-topbar">
      <a class="doc-logo" href="/index.php" aria-label="Hoosier Online home">
        <img src="/assets/brand/logo_primary.png" alt="Hoosier Online">
      </a>
      <nav class="doc-actions">
        <a class="admin-btn admin-btn-secondary" href="/admin.php">Admin</a>
        <a class="admin-btn admin-btn-secondary" href="/buildsystem.php?format=json">JSON</a>
      </nav>
    </div>

    <section class="doc-panel">
      <header class="doc-hero">
        <p class="doc-kicker">Fulfillment doctrine</p>
        <h1 class="doc-title">Build <em>System</em></h1>
        <p class="doc-lead">Defines how Hoosier Online fulfills a Business Front Door after a customer chooses and pays.</p>
      </header>

      <div class="doc-body">
        
<section class="doc-section">
  <h2>Fulfillment Thesis</h2>
  <blockquote class="doc-quote"><?= hp_h($buildsystem['fulfillment_thesis']) ?></blockquote>
</section>

<section class="doc-section">
  <h2>Core Flow</h2>
  <?= hp_list($buildsystem['core_flow']) ?>
</section>

<section class="doc-section">
  <h2>Build Stages</h2>
  <div class="doc-grid">
    <?php foreach ($buildsystem['build_stages'] as $stage): ?>
      <article class="doc-card">
        <h3><?= hp_h($stage['stage']) ?></h3>
        <p><?= hp_h($stage['goal']) ?></p>
        <?= hp_list($stage['outputs']) ?>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="doc-section">
  <h2>Template Families</h2>
  <div class="doc-grid">
    <?php foreach ($buildsystem['template_families'] as $family): ?>
      <article class="doc-card">
        <h3><?= hp_h($family['name']) ?></h3>
        <p><strong>Feel:</strong> <?= hp_h($family['feel']) ?></p>
        <h3>Best For</h3>
        <?= hp_list($family['best_for']) ?>
        <h3>Default Modules</h3>
        <?= hp_list($family['default_modules']) ?>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="doc-section">
  <h2>Feature Modules</h2>
  <div class="doc-grid">
    <?php foreach ($buildsystem['feature_modules'] as $module): ?>
      <article class="doc-card">
        <h3><?= hp_h($module['name']) ?></h3>
        <p><?= hp_h($module['purpose']) ?></p>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="doc-section">
  <h2>Preview to Build Mapping</h2>
  <div class="doc-grid">
    <?php foreach ($buildsystem['from_preview_to_build_mapping'] as $label => $value): ?>
      <article class="doc-card">
        <h3><?= hp_h(str_replace('_', ' ', $label)) ?></h3>
        <p><?= hp_h($value) ?></p>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="doc-section">
  <h2>QA Checklist</h2>
  <?= hp_list($buildsystem['qa_checklist']) ?>
</section>

<section class="doc-section">
  <h2>Launch Checklist</h2>
  <?= hp_list($buildsystem['launch_checklist']) ?>
</section>

<section class="doc-section">
  <h2>Support Rules</h2>
  <div class="doc-grid">
    <?php foreach ($buildsystem['support_rules'] as $label => $rules): ?>
      <article class="doc-card">
        <h3><?= hp_h($label) ?></h3>
        <?= hp_list($rules) ?>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="doc-section">
  <h2>Fulfillment Boundaries</h2>
  <?= hp_list($buildsystem['fulfillment_boundaries']) ?>
</section>

        <p class="machine-note">Machine-readable data is embedded in this page and available at <code>/buildsystem.php?format=json</code>. PHP include returns the document array.</p>
      </div>
    </section>
  </main>
</body>
</html>
<?php exit; ?>
