<?php
declare(strict_types=1);

$product = json_decode(<<<'JSON'
{
  "schema": "hoosier_online.product_definition.v2",
  "version": "HO-PRODUCT-023",
  "status": "working_locked",
  "purpose": "Canonical product, pricing, scope, renewal, delivery, ownership, and customer responsibility definition for Hoosier Online Business Front Door.",
  "core_offer": {
    "name": "Business Front Door",
    "definition": "Hoosier Online builds Business Front Doors for local operators.",
    "plain_pitch": "You do the work. Hoosier Online handles the online front door: customers can find you, trust you, see what you offer, contact you, request work, book time, and pay you.",
    "what_it_is": "A managed online setup for a small-town business, combining a public business page/app, customer contact/request path, service/product/work display, and practical cleanup of the online mess around it.",
    "what_it_is_not": [
      "Not a giant agency website project.",
      "Not a guaranteed lead-generation machine.",
      "Not paid ads.",
      "Not unlimited marketing support.",
      "Not a promise that the owner will close jobs.",
      "Not a replacement for answering customers, doing good work, or running the business."
    ],
    "positioning_rules": [
      "Do not lead with website, SEO, automation, or tech tools.",
      "Those are ingredients. The customer buys the setup.",
      "The Me categories are philosophical, but they define the deliverables.",
      "The customer-facing phrase is Business Front Door."
    ]
  },
  "front_door_build_spec": [
    {
      "module": "Hero",
      "purpose": "Make the business understandable in the first few seconds.",
      "typical_content": [
        "business name",
        "short promise",
        "service area",
        "primary call/request button",
        "click-to-call"
      ]
    },
    {
      "module": "Business Summary",
      "purpose": "Explain who they are and what kind of work they do.",
      "typical_content": [
        "short description",
        "owner/business tone",
        "local positioning",
        "who they serve"
      ]
    },
    {
      "module": "Services / Offers",
      "purpose": "Show what customers can hire, buy, request, or ask about.",
      "typical_content": [
        "service cards",
        "product/offer cards",
        "packages",
        "common jobs",
        "public pricing when appropriate"
      ]
    },
    {
      "module": "Proof / Gallery",
      "purpose": "Make the business feel real and credible.",
      "typical_content": [
        "photos",
        "before/after",
        "portfolio",
        "work examples",
        "reviews/testimonials if available"
      ]
    },
    {
      "module": "Service Area / Location",
      "purpose": "Make it clear where the business operates.",
      "typical_content": [
        "towns served",
        "map/link if useful",
        "mobile/local operation notes",
        "hours when appropriate"
      ]
    },
    {
      "module": "Contact / Request Form",
      "purpose": "Give customers a clean next step.",
      "typical_content": [
        "name",
        "phone/email",
        "service needed",
        "message",
        "preferred timing",
        "photo upload when useful"
      ]
    },
    {
      "module": "Booking / Request Path",
      "purpose": "Let customers request a job, estimate, visit, appointment, consultation, or time slot.",
      "typical_content": [
        "request form",
        "booking link",
        "availability note",
        "confirmation message"
      ]
    },
    {
      "module": "Payment / Deposit Path",
      "purpose": "Make paying or depositing simple when the business needs it.",
      "typical_content": [
        "payment link",
        "deposit link",
        "invoice link",
        "QR payment path",
        "payment instructions"
      ]
    },
    {
      "module": "Profile / Social / Google Links",
      "purpose": "Connect the Front Door to the business's existing presence.",
      "typical_content": [
        "Google Business Profile",
        "Facebook",
        "Instagram",
        "existing website if useful",
        "review link"
      ]
    },
    {
      "module": "Footer / Business Info",
      "purpose": "Give basic legitimacy and utility.",
      "typical_content": [
        "business name",
        "contact",
        "service area",
        "hours",
        "copyright",
        "Hoosier Online management note if used"
      ]
    }
  ],
  "me_framework": [
    {
      "name": "Find Me",
      "deliverable": "Customers can discover the business.",
      "standard": "Clean online destination, correct business info, service-area clarity, Google/social/link cleanup.",
      "managed": "More active cleanup and adjustment of online paths after launch."
    },
    {
      "name": "Trust Me",
      "deliverable": "The business looks real, current, and worth contacting.",
      "standard": "Clean design, clear copy, photos, services, credibility signals.",
      "managed": "More polish, updates, credibility improvements, photos, seasonal proof, or service changes."
    },
    {
      "name": "Contact Me",
      "deliverable": "Customers can call, message, or submit a request without guessing what to do.",
      "standard": "Contact/request form, click-to-call, messaging links when appropriate, simple lead path.",
      "managed": "More adjustments to forms, notifications, routing, and request flow."
    },
    {
      "name": "Show Me",
      "deliverable": "The page/app displays what the business offers.",
      "standard": "Services, products, work examples, photos, prices, menus, or offers when appropriate.",
      "managed": "More work, products, services, or offers can be added or rotated over time."
    },
    {
      "name": "Book Me",
      "deliverable": "Customers can request an appointment, estimate, job, consultation, or time slot.",
      "standard": "Booking/request path when it fits the business.",
      "managed": "More help refining booking/request workflows."
    },
    {
      "name": "Pay Me",
      "deliverable": "Customers can pay or deposit when needed.",
      "standard": "Payment, deposit, invoice, or checkout links can be included.",
      "managed": "More help adjusting payment/deposit links and customer payment paths."
    },
    {
      "name": "Fix Me",
      "deliverable": "Existing online mess gets cleaned up enough that the new setup works.",
      "standard": "Obvious broken, outdated, confusing, or embarrassing online issues get cleaned up.",
      "managed": "More hands-on support cleaning up issues as they appear."
    }
  ],
  "offers": [
    {
      "name": "Standard Front Door",
      "price": "$499",
      "included_service_period": "1 year of service included",
      "renewal": "$250/year or $25/month after year one",
      "best_for": "Local businesses that need a clean online front door without heavy ongoing changes.",
      "scope_summary": "Launch and maintain a complete Business Front Door for a local operator.",
      "includes": [
        "hosted business page/app",
        "business info and service area",
        "services/products/work display",
        "photos/gallery section",
        "contact/request form",
        "click-to-call",
        "Google/Facebook/social links",
        "booking/request path",
        "payment/deposit link when needed",
        "basic cleanup of obvious old/broken info",
        "mobile-friendly layout",
        "hosting included for one year",
        "light maintenance and reasonable small updates for one year"
      ],
      "included_updates": [
        "small text changes",
        "contact info changes",
        "hours/service-area updates",
        "minor photo swaps",
        "button/link updates",
        "small service/offer wording adjustments"
      ],
      "not_included_without_quote": [
        "major redesign",
        "new custom app system",
        "paid ad management",
        "large new sections",
        "heavy content entry",
        "advanced integrations",
        "custom database workflows beyond the initial Front Door",
        "unlimited changes"
      ]
    },
    {
      "name": "Managed Front Door",
      "price": "$999",
      "included_service_period": "3 months of managed service included",
      "renewal": "$250/quarter or $750/year after the first 3 months",
      "best_for": "Businesses that want more hands-on help after launch.",
      "scope_summary": "Launch the Front Door and actively help refine/manage it during the included managed period.",
      "includes": [
        "everything in Standard",
        "more hands-on setup",
        "more photos/services/offers loaded",
        "stronger service/product presentation",
        "expanded gallery or work display",
        "more cleanup of existing online mess",
        "more form/request workflow help",
        "more frequent updates during the included period",
        "seasonal offer changes",
        "priority fixes",
        "simple app-style features when needed"
      ],
      "included_updates": [
        "more frequent content updates",
        "seasonal offer changes",
        "gallery/service/product additions within reason",
        "form/request-flow adjustments",
        "more active cleanup support",
        "priority fixes during the managed period"
      ],
      "not_included_without_quote": [
        "full marketing campaign management",
        "paid ads",
        "custom enterprise software",
        "major rebuilds",
        "complex integrations",
        "large product catalogs",
        "ongoing daily content management",
        "unlimited revisions"
      ]
    }
  ],
  "required_customer_inputs": {
    "minimum_to_start": [
      "business name",
      "business type",
      "primary contact person",
      "phone",
      "email",
      "service area or location",
      "basic service/product list",
      "preferred customer action",
      "current links: Google/Facebook/website/social if available"
    ],
    "needed_to_launch_well": [
      "logo if available",
      "photos if available",
      "examples of work/products/services",
      "hours if relevant",
      "payment/deposit link if needed",
      "booking/scheduling preference if needed",
      "reviews/testimonials if available",
      "short business description or owner notes"
    ],
    "managed_extra_inputs": [
      "more photos",
      "seasonal offers",
      "detailed service or product notes",
      "workflow preferences",
      "pricing/menu details if public",
      "customer intake preferences",
      "follow-up preferences"
    ]
  },
  "delivery_timeline_rules": {
    "fast_start": "Work can begin quickly after payment and required information are received.",
    "target": "The system is designed to make many Front Door builds possible in under 24 hours after usable information is received, but no instant delivery is guaranteed.",
    "depends_on": [
      "customer responsiveness",
      "availability of business information",
      "photo/content readiness",
      "domain/payment/link access",
      "complexity of requested features"
    ],
    "no_guarantee": "Hoosier Online should not promise instant launch or guaranteed same-day completion."
  },
  "add_ons": [
    {
      "name": "Domain setup",
      "pricing_note": "quote or pass-through cost plus setup"
    },
    {
      "name": "Business email setup",
      "pricing_note": "quoted setup plus third-party cost if any"
    },
    {
      "name": "Extra page/section",
      "pricing_note": "quoted separately"
    },
    {
      "name": "Extra form/workflow",
      "pricing_note": "quoted separately"
    },
    {
      "name": "Logo/basic brand cleanup",
      "pricing_note": "quoted separately"
    },
    {
      "name": "Photo cleanup",
      "pricing_note": "quoted separately"
    },
    {
      "name": "Google Business Profile cleanup",
      "pricing_note": "quoted separately"
    },
    {
      "name": "Large gallery/product loading",
      "pricing_note": "quoted separately"
    },
    {
      "name": "Rush launch",
      "pricing_note": "quoted separately"
    },
    {
      "name": "QR code package",
      "pricing_note": "quoted separately"
    },
    {
      "name": "Printed flyer/card export",
      "pricing_note": "quoted separately"
    },
    {
      "name": "Advanced booking/payment setup",
      "pricing_note": "quoted separately"
    }
  ],
  "policies": {
    "ownership": "Customer owns their business information, photos, logo, and content. Customer owns their domain if purchased in their name. Hoosier Online owns and manages the hosted Front Door system/templates unless transfer/export is separately agreed.",
    "renewal_standard": "Standard renewal is optional after the first year. If not renewed, hosting/service may stop after a grace period.",
    "renewal_managed": "Managed service renews quarterly or annually after the included period.",
    "cancellation": "Setup fees cover build/setup work and are not treated as monthly service fees. If service is cancelled or not renewed, continued hosting, maintenance, and updates may stop after any stated grace period.",
    "transfer_export": "If a customer wants to move elsewhere, Hoosier Online can discuss export or transfer options depending on what was built. Transfer/export may require a separate quote.",
    "customer_responsibility": "Hoosier Online can make the front door work. The business is responsible for answering customers, quoting jobs, doing the work, collecting payment, and serving customers well.",
    "performance_disclaimer": "Hoosier Online improves the online customer path but does not guarantee leads, sales, bookings, revenue, search ranking, or customer behavior."
  },
  "sales_page_spine": {
    "headline": "Your business needs a front door online.",
    "subheadline": "Hoosier Online sets up the place customers go to find you, trust you, see what you offer, contact you, request work, book time, and pay you.",
    "primary_cta": "Start My Front Door",
    "problem_questions": [
      "Who are you?",
      "What do you do?",
      "Can I trust you?",
      "How do I contact you?",
      "Can I see your work?",
      "Can I request a job?",
      "Can I pay or deposit?"
    ],
    "verbal_pitch": "I set up your Business Front Door online. That means customers have one clean place to find you, see what you do, trust you, contact you, request work, book time, and pay you. Standard is $499 and includes the first year. After that, it is $250/year if you want to keep it active. Managed is $999 and includes more hands-on help for the first three months, then $250/quarter if you want ongoing managed support."
  }
}
JSON, true);

if (isset($_GET['format']) && $_GET['format'] === 'json') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($product, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') !== realpath(__FILE__)) {
    return $product;
}

function hp_h(mixed $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function hp_list(array $items): string {
    $html = '<ul class="doc-list">';
    foreach ($items as $item) {
        if (is_array($item)) {
            $item = json_encode($item, JSON_UNESCAPED_SLASHES);
        }
        $html .= '<li>' . hp_h($item) . '</li>';
    }
    $html .= '</ul>';
    return $html;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hoosier Online Product Definition</title>
  <link rel="icon" href="/favicon.ico">
  <link rel="stylesheet" href="/assets/css/site.css?v=023-docs">
  <link rel="stylesheet" href="/assets/css/admin.css?v=023-docs">
  <script type="application/json" id="ho-doc-machine"><?= hp_h(json_encode($product, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></script>
  <style>
    body { background: var(--ho-bg, #F8F1E3); }
    .doc-shell { width: min(1120px, calc(100% - 28px)); margin: 0 auto; padding: 26px 0 52px; }
    .doc-topbar { display: flex; justify-content: space-between; align-items: center; gap: 16px; margin-bottom: 18px; }
    .doc-logo img { width: clamp(220px, 24vw, 330px); height: auto; display: block; filter: drop-shadow(0 8px 14px rgba(84,58,31,.06)); }
    .doc-actions { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 8px; }
    .doc-panel { background: linear-gradient(180deg, rgba(255,253,247,.84), rgba(255,248,234,.72)); border: 1px solid var(--ho-border, rgba(139,104,68,.22)); border-radius: 34px; box-shadow: 0 24px 80px rgba(84,58,31,.10), inset 0 1px 0 rgba(255,255,255,.76); overflow: hidden; }
    .doc-hero { padding: clamp(28px, 5vw, 48px); border-bottom: 1px solid rgba(139,104,68,.18); background: radial-gradient(circle at 88% 0%, rgba(233,169,40,.14), transparent 18rem), linear-gradient(135deg, rgba(177,18,23,.045), transparent 40%), rgba(255,248,234,.62); }
    .doc-kicker { margin: 0 0 10px; color: var(--ho-primary, #B11217); text-transform: uppercase; letter-spacing: .18em; font-size: 12px; font-weight: 880; }
    .doc-title { margin: 0; font-family: var(--ho-font-display, "Arial Narrow", sans-serif); font-size: clamp(54px, 8vw, 104px); line-height: .86; letter-spacing: .03em; text-transform: uppercase; }
    .doc-title em { color: var(--ho-primary, #B11217); font-style: normal; }
    .doc-lead { max-width: 78ch; margin: 16px 0 0; color: var(--ho-muted, #6E665C); font-size: 18px; }
    .doc-body { padding: clamp(20px, 3vw, 30px); display: grid; gap: 22px; }
    .doc-section { border: 1px solid var(--ho-border, rgba(139,104,68,.22)); border-radius: 28px; padding: clamp(20px, 3vw, 28px); background: linear-gradient(180deg, rgba(255,255,255,.70), rgba(255,253,247,.56)); box-shadow: 0 14px 42px rgba(84,58,31,.06); }
    .doc-section h2 { margin: 0 0 14px; font-family: var(--ho-font-display, "Arial Narrow", sans-serif); font-size: clamp(38px, 5vw, 58px); line-height: .92; letter-spacing: .04em; text-transform: uppercase; }
    .doc-section h3 { margin: 0 0 8px; font-family: var(--ho-font-display, "Arial Narrow", sans-serif); font-size: 30px; line-height: .96; letter-spacing: .035em; text-transform: uppercase; color: var(--ho-secondary, #2F6338); }
    .doc-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
    .doc-grid-three { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }
    .doc-card { border: 1px solid var(--ho-border, rgba(139,104,68,.22)); border-radius: 24px; padding: 20px; background: rgba(255,255,255,.62); }
    .doc-price { font-family: var(--ho-font-display, "Arial Narrow", sans-serif); font-size: clamp(48px, 6vw, 72px); line-height: .86; color: var(--ho-primary, #B11217); margin: 4px 0 10px; }
    .doc-sub { color: var(--ho-muted, #6E665C); margin: 0 0 14px; }
    .doc-list { margin: 10px 0 0; padding-left: 20px; }
    .doc-list li + li { margin-top: 5px; }
    .doc-quote { margin: 0; padding: 20px; border-left: 6px solid var(--ho-primary, #B11217); border-radius: 18px; background: rgba(255,255,255,.58); font-size: 19px; }
    .machine-note { color: var(--ho-muted, #6E665C); font-size: 13px; }
    @media (max-width: 820px) { .doc-topbar, .doc-grid, .doc-grid-three { grid-template-columns: 1fr; display: grid; } .doc-actions { justify-content: flex-start; } .doc-logo img { width: min(335px, 86vw); } .doc-panel { border-radius: 28px; } }
  </style>
</head>
<body>
  <main class="doc-shell">
    <div class="doc-topbar">
      <a class="doc-logo" href="/index.php" aria-label="Hoosier Online home">
        <img src="/assets/brand/logo_primary.png" alt="Hoosier Online">
      </a>
      <nav class="doc-actions">
        <a class="admin-btn admin-btn-secondary" href="/admin.php">Admin</a>
        <a class="admin-btn admin-btn-secondary" href="/product.php?format=json">JSON</a>
      </nav>
    </div>

    <section class="doc-panel">
      <header class="doc-hero">
        <p class="doc-kicker">Product definition</p>
        <h1 class="doc-title">Business <em>Front Door</em></h1>
        <p class="doc-lead">Hoosier Online builds Business Front Doors for local operators.</p>
      </header>

      <div class="doc-body">
        
<section class="doc-section">
  <h2>Core Offer</h2>
  <blockquote class="doc-quote"><?= hp_h($product['core_offer']['plain_pitch']) ?></blockquote>
  <p><?= hp_h($product['core_offer']['what_it_is']) ?></p>
  <h3>What It Is Not</h3>
  <?= hp_list($product['core_offer']['what_it_is_not']) ?>
</section>

<section class="doc-section">
  <h2>Build Spec</h2>
  <div class="doc-grid">
    <?php foreach ($product['front_door_build_spec'] as $module): ?>
      <article class="doc-card">
        <h3><?= hp_h($module['module']) ?></h3>
        <p><?= hp_h($module['purpose']) ?></p>
        <?= hp_list($module['typical_content']) ?>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="doc-section">
  <h2>Offers</h2>
  <div class="doc-grid">
    <?php foreach ($product['offers'] as $offer): ?>
      <article class="doc-card">
        <h3><?= hp_h($offer['name']) ?></h3>
        <div class="doc-price"><?= hp_h($offer['price']) ?></div>
        <p><strong><?= hp_h($offer['included_service_period']) ?></strong></p>
        <p><strong>Renewal:</strong> <?= hp_h($offer['renewal']) ?></p>
        <p><strong>Best for:</strong> <?= hp_h($offer['best_for']) ?></p>
        <h3>Includes</h3>
        <?= hp_list($offer['includes']) ?>
        <h3>Included Updates</h3>
        <?= hp_list($offer['included_updates']) ?>
        <h3>Not Included Without Quote</h3>
        <?= hp_list($offer['not_included_without_quote']) ?>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="doc-section">
  <h2>Me Deliverables</h2>
  <div class="doc-grid">
    <?php foreach ($product['me_framework'] as $lane): ?>
      <article class="doc-card">
        <h3><?= hp_h($lane['name']) ?></h3>
        <p><?= hp_h($lane['deliverable']) ?></p>
        <p><strong>Standard:</strong> <?= hp_h($lane['standard']) ?></p>
        <p><strong>Managed:</strong> <?= hp_h($lane['managed']) ?></p>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="doc-section">
  <h2>Required Inputs</h2>
  <div class="doc-grid-three">
    <?php foreach ($product['required_customer_inputs'] as $label => $items): ?>
      <article class="doc-card">
        <h3><?= hp_h(str_replace('_', ' ', $label)) ?></h3>
        <?= hp_list($items) ?>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="doc-section">
  <h2>Timeline Rules</h2>
  <p><strong>Fast start:</strong> <?= hp_h($product['delivery_timeline_rules']['fast_start']) ?></p>
  <p><strong>Target:</strong> <?= hp_h($product['delivery_timeline_rules']['target']) ?></p>
  <p><strong>No guarantee:</strong> <?= hp_h($product['delivery_timeline_rules']['no_guarantee']) ?></p>
  <h3>Depends On</h3>
  <?= hp_list($product['delivery_timeline_rules']['depends_on']) ?>
</section>

<section class="doc-section">
  <h2>Add-ons</h2>
  <div class="doc-grid">
    <?php foreach ($product['add_ons'] as $addOn): ?>
      <article class="doc-card">
        <h3><?= hp_h($addOn['name']) ?></h3>
        <p><?= hp_h($addOn['pricing_note']) ?></p>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="doc-section">
  <h2>Policies</h2>
  <div class="doc-grid">
    <?php foreach ($product['policies'] as $label => $policy): ?>
      <article class="doc-card">
        <h3><?= hp_h(str_replace('_', ' ', $label)) ?></h3>
        <p><?= hp_h($policy) ?></p>
      </article>
    <?php endforeach; ?>
  </div>
</section>

        <p class="machine-note">Machine-readable data is embedded in this page and available at <code>/product.php?format=json</code>. PHP include returns the document array.</p>
      </div>
    </section>
  </main>
</body>
</html>
<?php exit; ?>
